<?php return array (
  'root' => 
  array (
    'pretty_version' => 'dev-main',
    'version' => 'dev-main',
    'aliases' => 
    array (
    ),
    'reference' => '43c614dc6629909234202976c5ee5590255d1098',
    'name' => 'dlxplugins/gb-hacks',
  ),
  'versions' => 
  array (
    'dlxplugins/gb-hacks' => 
    array (
      'pretty_version' => 'dev-main',
      'version' => 'dev-main',
      'aliases' => 
      array (
      ),
      'reference' => '43c614dc6629909234202976c5ee5590255d1098',
    ),
  ),
);
